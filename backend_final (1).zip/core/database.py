import mysql.connector


DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "estoque_sensores"
}


def conectar():
    """
    Cria e retorna uma conexão com o banco de dados MySQL.
    """
    return mysql.connector.connect(**DB_CONFIG)